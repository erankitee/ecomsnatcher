<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('admin/orders'); ?>" class="btn btn-default btn-add"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <h3>Order Details</h3>

                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">

                        <table class="table">
                            <tbody>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Order ID#</strong></td>
                                <td><?php echo e($order->order_number); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Name:</strong></td>
                                <td><?php echo e($order->customer_name); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Email:</strong></td>
                                <td><?php echo e($order->customer_email); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Phone:</strong></td>
                                <td><?php echo e($order->customer_phone); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Address:</strong></td>
                                <td><?php echo e($order->customer_address); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer City:</strong></td>
                                <td><?php echo e($order->customer_city); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Postal Code:</strong></td>
                                <td><?php echo e($order->customer_zip); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Total Product:</strong></td>
                                <td><?php echo e(array_sum($order->quantities)); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Total Cost:</strong></td>
                                <td>$<?php echo e($order->pay_amount); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Ordered Date:</strong></td>
                                <td><?php echo e($order->booking_date); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Payment Method:</strong></td>
                                <td><?php echo e($order->method); ?></td>
                            </tr>
                        <?php if($order->method != "Cash On Delivery"): ?>
                            <?php if($order->method=="Stripe"): ?>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong><?php echo e($order->method); ?> Charge ID:</strong></td>
                                    <td><?php echo e($order->charge_id); ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong><?php echo e($order->method); ?> Transection ID:</strong></td>
                                <td><?php echo e($order->txnid); ?></td>
                            </tr>
                        <?php endif; ?>


                            <table class="table">
                                <h4 class="text-center">Products Ordered</h4><hr>
                                <thead>
                                <tr>
                                    <th width="10%">Product ID#</th>
                                    <th>Product Title</th>
                                    <th width="5%">Quantity</th>
                                    <th width="10%">Size</th>
                                    <th width="20%">Vendor</th>
                                    <th width="10%">Status</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if(\App\Product::where('id',$product->productid)->count() > 0): ?>
                                            <td><?php echo e($product->productid); ?></td>
                                            <td><a target="_blank" href="<?php echo e(url('/product')); ?>/<?php echo e($product->productid); ?>/<?php echo e(str_replace(' ','-',strtolower(\App\Product::findOrFail($product->productid)->title))); ?>"><?php echo e(\App\Product::findOrFail($product->productid)->title); ?></a></td>
                                            <td><?php echo e($product->quantity); ?></td>
                                            <td><?php echo e($product->size); ?></td>
                                            <td>
                                                <?php if($product->owner == "vendor"): ?>
                                                    <?php echo e(\App\Vendors::findOrFail($product->vendorid)->shop_name); ?>

                                                <?php else: ?>
                                                    Admin
                                                <?php endif; ?>
                                            </td>
                                            <td class="o-<?php echo e($product->status); ?>"><?php echo e(ucfirst($product->status)); ?></td>
                                        <?php else: ?>
                                            <td><?php echo e($product->productid); ?></td>
                                            <td style="color:red;">Product Deleted</td>
                                            <td><?php echo e($product->quantity); ?></td>
                                            <td><?php echo e($product->size); ?></td>
                                            <td>
                                                <?php if($product->owner == "vendor"): ?>
                                                    <?php if(\App\Vendors::where('id',$product->vendorid)->count() > 0): ?>
                                                        <?php echo e(\App\Vendors::findOrFail($product->vendorid)->shop_name); ?>

                                                    <?php else: ?>
                                                        <span style="color:red;">Vendor Account Deleted</span>
                                                    <?php endif; ?>
                                                <?php else: ?>
                                                    Admin
                                                <?php endif; ?>
                                            </td>
                                            <td class="o-<?php echo e($product->status); ?>"><?php echo e(ucfirst($product->status)); ?></td>
                                        <?php endif; ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                
                                    
                                        
                                            
                                            
                                            
                                            
                                        
                                            
                                            
                                            
                                            
                                        
                                    
                                

                                </tbody>
                            </table>

                            <tr>
                                <td width="30%"></td>
                                <td><a href="email/<?php echo e($order->id); ?>" class="btn btn-primary"><i class="fa fa-send"></i> Contact Customer</a>
                                </td>
                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>