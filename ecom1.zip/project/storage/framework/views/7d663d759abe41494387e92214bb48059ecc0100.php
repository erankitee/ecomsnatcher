<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('vendor/withdrawmoney'); ?>" class="btn btn-primary btn-add"><i class="fa fa-download"></i> Withdraw Now</a>
                    </div>
                    <h3>My Withdraws</h3>
                    <div class="go-line"></div>
                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">
                        <div id="response">
                            <?php if(Session::has('message')): ?>
                                <div class="alert alert-success alert-dismissable">
                                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                                    <?php echo e(Session::get('message')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <table class="table table-striped table-bordered" cellspacing="0" id="example" width="100%">
                            <thead>
                            <tr>

                                <th>Withdraw Date</th>
                                <th width="10%">Method</th>
                                <th width="30%">Account</th>
                                <th width="10%">Amount</th>
                                <th width="10%">Status</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $withdraws; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdraw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($withdraw->created_at); ?></td>
                                    <td><?php echo e($withdraw->method); ?></td>
                                    <?php if($withdraw->method != "Bank"): ?>
                                        <td><?php echo e($withdraw->acc_email); ?></td>
                                    <?php else: ?>
                                        <td><?php echo e($withdraw->iban); ?></td>
                                    <?php endif; ?>
                                    <td>$<?php echo e($withdraw->amount); ?></td>
                                    <td><?php echo e(ucfirst($withdraw->status)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('vendor.includes.master-vendor', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>