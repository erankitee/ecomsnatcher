<?php $__env->startSection('content'); ?>


    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row" style="background-color:rgba(0,0,0,0.7);">

            <div style="margin: 3% 0px 3% 0px;">
                <div class="text-center" style="color: #FFF;padding: 20px;">
                    <?php if(is_object($category)): ?>
                        <h1><?php echo e($category->name); ?></h1>
                    <?php else: ?>
                        <h1>No Category Found</h1>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>

    <div id="wrapper" class="go-section">
        <section class="wow fadeInUp go-products">
            <div class="container">
                <div class="row">
                    <div class="col-md-3" style="padding: 0">
                    <div class="row" style="margin-bottom: 20px;">
                        <h3 class="allcats">Filter Option</h3>
                        <select id="sortby" class="filter-option form-control">
                        <?php if($sort == "new"): ?>
                            <option value="new" selected>Sort by Latest Products</option>
                        <?php else: ?>
                            <option value="new">Sort by Latest Products</option>
                        <?php endif; ?>
                        <?php if($sort == "old"): ?>
                            <option value="old" selected>Sort by Oldest Products</option>
                        <?php else: ?>
                            <option value="old">Sort by Oldest Products</option>
                        <?php endif; ?>
                        <?php if($sort == "low"): ?>
                            <option value="low" selected>Sort by Lowest Price</option>
                        <?php else: ?>
                            <option value="low">Sort by Lowest Price</option>
                        <?php endif; ?>
                        <?php if($sort == "high"): ?>
                            <option value="high" selected>Sort by Highest Price</option>
                        <?php else: ?>
                            <option value="high">Sort by Highest Price</option>
                        <?php endif; ?>

                        </select>
                        </div>

                        <h3 class="allcats">All Categories</h3>
                        <div id="left" class="span3">
                            <ul id="menu-group-1" class="nav menu">
                                <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="item-1 deeper parent">
                                        <a class="" href="<?php echo e(url('/category')); ?>/<?php echo e($menu->slug); ?>">
                                            <span data-toggle="collapse" data-parent="#menu-group-1" href="#<?php echo e($menu->slug); ?>-1" class="sign"><i class="fa fa-plus"></i></span>
                                            <span class="lbl"><?php echo e($menu->name); ?></span>
                                        </a>
                                        <ul class="children nav-child unstyled small collapse" id="<?php echo e($menu->slug); ?>-1">
                                            <?php $__currentLoopData = \App\Category::where('mainid',$menu->id)->where('role','sub')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <li class="item-2 deeper parent">
                                                    <a class="" href="<?php echo e(url('/category')); ?>/<?php echo e($submenu->slug); ?>">
                                                        <span data-toggle="collapse" data-parent="#menu-group-1" href="#<?php echo e($submenu->slug); ?>-1" class="sign"><i class="fa fa-plus"></i></span>
                                                        <span class="lbl"><?php echo e($submenu->name); ?></span>
                                                    </a>

                                                    <ul class="children nav-child unstyled small collapse" id="<?php echo e($submenu->slug); ?>-1">

                                                            <?php $__currentLoopData = \App\Category::where('subid',$submenu->id)->where('role','child')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childmenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li class="item-3">
                                                                <a class="" href="<?php echo e(url('/category')); ?>/<?php echo e($childmenu->slug); ?>">
                                                                    <span class="sign"><i class="fa fa-chevron-right"></i></span>
                                                                    <span class="lbl"><?php echo e($childmenu->name); ?></span>
                                                                </a>
                                                            </li>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>

                    <div class="col-md-9">
                        <div id="products">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="col-xs-6 col-sm-4 product">
                        <article class="col-item">
                            <div class="photo">
                                <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>"> <img src="<?php echo e(url('/assets/images/products')); ?>/<?php echo e($product->feature_image); ?>" class="img-responsive" style="height: 320px;" alt="Product Image" /> </a>
                            </div>
                            <div class="info">
                                <div class="row">
                                    <div class="price-details">
                                        <a href="<?php echo e(url('/product')); ?>/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ','-',strtolower($product->title))); ?>" class="row" style="min-height: 60px">
                                            <h1><?php echo e($product->title); ?></h1>
                                        </a>
                                        <div class="pull-left">
                                            <?php if($product->previous_price != ""): ?>
                                                <span class="price-old">$<?php echo e($product->previous_price); ?></span>
                                            <?php else: ?>
                                            <?php endif; ?>
                                            <span class="price-new">$<?php echo e($product->price); ?></span>
                                        </div>
                                        <div class="pull-right">
                                            <span class="review">
                                                <?php for($i=1;$i<=5;$i++): ?>
                                                    <?php if($i <= \App\Review::where('productid',$product->id)->avg('rating')): ?>
                                                        <i class="fa fa-star"></i>
                                                    <?php else: ?>
                                                        <i class="fa fa-star-o"></i>
                                                    <?php endif; ?>
                                                <?php endfor; ?>
                                            </span>
                                        </div>

                                    </div>

                                </div>
                                <div class="separator clear-left">

                                    <form>
                                        <p>
                                        <?php echo e(csrf_field()); ?>

                                        <?php if(Session::has('uniqueid')): ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                        <?php else: ?>
                                            <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                        <?php endif; ?>
                                        <input type="hidden" name="title" value="<?php echo e($product->title); ?>">
                                        <input type="hidden" name="product" value="<?php echo e($product->id); ?>">
                                        <input type="hidden" id="cost" name="cost" value="<?php echo e($product->price); ?>">
                                        <input type="hidden" id="quantity" name="quantity" value="1">
                                        <?php if($product->stock != 0): ?>
                                            <button type="button" class="button style-10 to-cart">Add to cart</button>
                                        <?php else: ?>
                                            <button type="button" class="button style-10 to-cart" disabled>Out Of Stock</button>
                                        <?php endif; ?>
                                        
                                        </p>
                                    </form>

                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <h3>No Product Found in This Category.</h3>
                    <?php endif; ?>
                    </div>
                        <?php if(count($products) > 0): ?>
                            <div class="col-sm-12 col-xs-12 col-md-12 text-center" style="margin-top: 15px;">
                                <input type="hidden" id="page" value="2">
                                <div class="col-md-12">
                                <img id="load" src="<?php echo e(url('/assets/images')); ?>/default.gif" style="display: none;width: 80px;"></div>
                                <button type="button" id="load-more" class="button style-3">Load More</button>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>

    $("#sortby").change(function () {
        var sort = $("#sortby").val();
        window.location = "<?php echo e(url('/category')); ?>/<?php echo e($category->slug); ?>?sort="+sort;
    });

    $("#load-more").click(function () {
        $("#load").show();
        var slug = "<?php echo e($category->slug); ?>";
        var page = $("#page").val();
        var sort = $("#sortby").val();
        $.get("<?php echo e(url('/')); ?>/loadcategory/"+slug+"/"+page+"?sort="+sort, function(data, status){
            $("#load").fadeOut();
            $("#products").append(data);
            //alert("Data: " + data + "\nStatus: " + status);
            $("#page").val(parseInt($("#page").val())+1);
            if ($.trim(data) == ""){
                $("#load-more").fadeOut();
            }

        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>