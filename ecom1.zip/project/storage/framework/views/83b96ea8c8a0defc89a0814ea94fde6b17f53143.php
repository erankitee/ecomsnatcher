<?php $__env->startSection('content'); ?>

    <div id="page-wrapper">
        <div class="container-fluid">
            <div class="row" id="main">
                <!-- Page Heading -->
                <div class="go-title">
                    <div class="pull-right">
                        <a href="<?php echo url('admin/orders'); ?>" class="btn btn-default btn-add"><i class="fa fa-arrow-left"></i> Back</a>
                    </div>
                    <h3>Order Details</h3>

                </div>
                <!-- Page Content -->
                <div class="panel panel-default">
                    <div class="panel-body">

                        <table class="table">
                            <tbody>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Order ID#</strong></td>
                                <td><?php echo e($order->order_number); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Name:</strong></td>
                                <td><?php echo e($order->customer_name); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Email:</strong></td>
                                <td><?php echo e($order->customer_email); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Phone:</strong></td>
                                <td><?php echo e($order->customer_phone); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Address:</strong></td>
                                <td><?php echo e($order->customer_address); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer City:</strong></td>
                                <td><?php echo e($order->customer_city); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Customer Postal Code:</strong></td>
                                <td><?php echo e($order->customer_zip); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Total Product:</strong></td>
                                <td><?php echo e(array_sum($order->quantities)); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Total Cost:</strong></td>
                                <td>$<?php echo e($order->pay_amount); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Ordered Date:</strong></td>
                                <td><?php echo e($order->booking_date); ?></td>
                            </tr>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong>Payment Method:</strong></td>
                                <td><?php echo e($order->method); ?></td>
                            </tr>
                        <?php if($order->method != "Cash On Delivery"): ?>
                            <?php if($order->method=="Stripe"): ?>
                                <tr>
                                    <td width="30%" style="text-align: right;"><strong><?php echo e($order->method); ?> Charge ID:</strong></td>
                                    <td><?php echo e($order->charge_id); ?></td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td width="30%" style="text-align: right;"><strong><?php echo e($order->method); ?> Transection ID:</strong></td>
                                <td><?php echo e($order->txnid); ?></td>
                            </tr>
                        <?php endif; ?>


                            <table class="table">
                                <h4 class="text-center">Products Ordered</h4><hr>
                                <thead>
                                <tr>
                                    <th width="10%">Product ID#</th>
                                    <th>Product Title</th>
                                    <th width="20%">Quantity</th>
                                    <th width="10%">Size</th>
                                </tr>
                                </thead>
                                <tbody>

                                <?php for($i=0;$i<=count($order->products)-1;$i++): ?>
                                    <tr>
                                    	<td><?php echo e($order->products[$i]); ?></td>
                                        <td><?php echo e(\App\Product::findOrFail($order->products[$i])->title); ?></td>
                                        <td><?php echo e($order->quantities[$i]); ?></td>
                                        <td><?php echo e(explode(',',$order->sizes)[$i]); ?></td>
                                    </tr>
                                <?php endfor; ?>

                                </tbody>
                            </table>

                            <tr>
                                <td width="30%"></td>
                                <td><a href="email/<?php echo e($order->id); ?>" class="btn btn-primary"><i class="fa fa-send"></i> Contact Customer</a>
                                </td>
                            </tr>

                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->


<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.includes.master-admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>