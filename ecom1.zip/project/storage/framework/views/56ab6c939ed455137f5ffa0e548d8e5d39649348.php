<?php $__env->startSection('content'); ?>

    <section class="go-section">
        <div class="row">
            <div class="container">
                <h2 class="text-center"><?php echo e($pagename); ?></h2>
                <hr>
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 text-center services">
                    <div class="services-div">
                        <h1><?php echo e($service->cost); ?>$</h1>
                        <p><?php echo e($service->details); ?></p>
                        <form action="<?php echo e(route('payment.submit')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" name="cmd" value="_xclick" />
                            <input type="hidden" name="no_note" value="1" />
                            <input type="hidden" name="lc" value="UK" />
                            <input type="hidden" name="currency_code" value="USD" />
                            <input type="hidden" name="bn" value="PP-BuyNowBF:btn_buynow_LG.gif:NonHostedGuest" />
                            <button type="submit" class="btn btn-views">Order Now</button>
                        </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>