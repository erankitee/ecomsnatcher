<?php $__env->startSection('content'); ?>

    <section class="container" style="margin-top: 20px;">
        <div class="content-push">

            <div class="breadcrumb-box">
                <a href="<?php echo e(url('/')); ?>">Home</a>
                <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[0])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[0])->first()->name); ?></a>
                <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[1])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[1])->first()->name); ?></a>
                <a href="<?php echo e(url('/category')); ?>/<?php echo e(\App\Category::where('id',$productdata->category[2])->first()->slug); ?>"><?php echo e(\App\Category::where('id',$productdata->category[2])->first()->name); ?></a>
                <a href="<?php echo e(url('/product')); ?>/<?php echo e($productdata->id); ?>/<?php echo e(str_replace(' ','-',strtolower($productdata->title))); ?>"><?php echo e($productdata->title); ?></a>
            </div>

            <div class="information-blocks">
                <div class="row">
                    <div class="col-sm-5 col-md-4 col-lg-5 information-entry">
                        <div class="product-preview-box">
                            <div class="swiper-container product-preview-swiper" data-autoplay="0" data-loop="1" data-speed="500" data-center="0" data-slides-per-view="1">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="product-zoom-image">
                                            <img src="<?php echo e(url('/')); ?>/assets/images/products/<?php echo e($productdata->feature_image); ?>" alt="" data-zoom="" />
                                        </div>
                                    </div>
                                    <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galdta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="swiper-slide">
                                            <div class="product-zoom-image">
                                                <img src="<?php echo e(url('/')); ?>/assets/images/gallery/<?php echo e($galdta->image); ?>" alt="" data-zoom="" />
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>
                                </div>
                                <div class="pagination"></div>
                                <div class="product-zoom-container">
                                    <div class="move-box">
                                        <img class="default-image" src="" alt="" />
                                        <img class="zoomed-image" src="" alt="" />
                                    </div>
                                    <div class="zoom-area"></div>
                                </div>
                            </div>
                            <div class="swiper-hidden-edges">
                                <div class="swiper-container product-thumbnails-swiper" data-autoplay="0" data-loop="0" data-speed="500" data-center="0" data-slides-per-view="responsive" data-xs-slides="3" data-int-slides="3" data-sm-slides="3" data-md-slides="4" data-lg-slides="4" data-add-slides="4">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide selected">
                                            <div class="paddings-container">
                                                <img src="<?php echo e(url('/')); ?>/assets/images/products/<?php echo e($productdata->feature_image); ?>" alt="" />
                                            </div>
                                        </div>
                                        <?php $__empty_1 = true; $__currentLoopData = $gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galdta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <div class="swiper-slide">
                                                <div class="paddings-container">
                                                    <img src="<?php echo e(url('/')); ?>/assets/images/gallery/<?php echo e($galdta->image); ?>" alt="" />
                                                </div>
                                            </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <?php endif; ?>


                                    </div>
                                    <div class="pagination"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-7 col-md-7 information-entry">
                        <div class="product-detail-box">
                            <h1 class="product-title"><?php echo e($productdata->title); ?></h1>
                            <?php if($productdata->stock != 0 || $productdata->stock === null ): ?>
                                <h3 class="product-subtitle"><i class="fa fa-check-circle fa-fw"></i> Available</h3>
                            <?php else: ?>
                                <h3 class="product-subtitle2"><i class="fa fa-times-circle fa-fw"></i> Not in Stock</h3>
                            <?php endif; ?>

                            <div class="rating-box">
                                <?php for($i=1;$i<=5;$i++): ?>
                                    <?php if($i <= \App\Review::ratings($productdata->id)): ?>
                                        <div class="star"><i class="fa fa-star"></i></div>
                                    <?php else: ?>
                                        <div class="star"><i class="fa fa-star-o"></i></div>
                                    <?php endif; ?>
                                <?php endfor; ?>

                                <div class="rating-number"><?php echo e(\App\Review::ratings($productdata->id)); ?><?php echo e(\App\Review::where('productid',$productdata->id)->count()); ?> Reviews</div>
                            </div>
                            <div class="product-description detail-info-entry"><?php echo e(substr(strip_tags($productdata->description), 0, 350)); ?>... <a id="showmore">Show More</a></div>
                            <div class="price detail-info-entry">
                                <?php if($productdata->previous_price != ""): ?>
                                    <div class="prev">$<?php echo e($productdata->previous_price); ?></div>
                                <?php else: ?>
                                <?php endif; ?>
                                <div class="current">$<span id="price"><?php echo e($productdata->price); ?></span></div>
                            </div>
                            
                                
                                
                                
                                
                                
                                
                                
                            
                            
                                
                                
                                
                                
                                
                                
                            
                            <div class="quantity-selector detail-info-entry">
                                <div class="detail-info-entry-title">Quantity</div>
                                <div class="entry number-minus">&nbsp;</div>
                                <div class="entry number">1</div>
                                <div class="entry number-plus">&nbsp;</div>
                            </div>

                            <div class="detail-info-entry">
                                <form id="cartfrom">
                                    <?php echo e(csrf_field()); ?>

                                    <?php if(Session::has('uniqueid')): ?>
                                        <input type="hidden" name="uniqueid" value="<?php echo e(Session::get('uniqueid')); ?>">
                                    <?php else: ?>
                                        <input type="hidden" name="uniqueid" value="<?php echo e(str_random(7)); ?>">
                                    <?php endif; ?>
                                    <input type="hidden" name="title" value="<?php echo e($productdata->title); ?>">
                                    <input type="hidden" name="product" value="<?php echo e($productdata->id); ?>">
                                    <input type="hidden" id="cost" name="cost" value="<?php echo e($productdata->price); ?>">
                                    <input type="hidden" id="quantity" name="quantity" value="1">
                                    <?php if($productdata->stock != 0 || $productdata->stock === null ): ?>
                                        <button type="button" class="button style-10 to-cart">Add to cart</button>
                                    <?php else: ?>
                                        <button type="button" class="button style-10 to-cart" disabled>Out Of Stock</button>
                                    <?php endif; ?>
                                    
                                </form>
                                <div class="clear"></div>
                            </div>
                            
                                
                                
                                
                                
                                
                            
                            <div class="share-box detail-info-entry">
                                <!-- AddToAny BEGIN -->
                                <div class="a2a_kit a2a_kit_size_32 a2a_default_style">
                                    <a class="a2a_dd" href="https://www.geniusocean.com"></a>
                                    <a class="a2a_button_facebook"></a>
                                    <a class="a2a_button_twitter"></a>
                                    <a class="a2a_button_google_plus"></a>
                                    <a class="a2a_button_linkedin"></a>
                                </div>
                                <script async src="https://static.addtoany.com/menu/page.js"></script>
                                <!-- AddToAny END -->
                                <div class="title">Share in social media</div>

                                <div class="clear"></div>
                            </div>
                        </div>
                    </div>
                    <div class="clear visible-xs visible-sm"></div>

                </div>
            </div>

            <div class="information-blocks">
                <div class="card">
                    <?php if(Session::has('message')): ?>
                        <div class="alert alert-success alert-dismissable">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                            <?php echo e(Session::get('message')); ?>

                        </div>
                    <?php endif; ?>
                    <ul class="nav nav-tabs" role="tablist">
                        <li role="presentation" class="active"><a href="#description" aria-controls="home" role="tab" data-toggle="tab">Full Description</a></li>
                        <li role="presentation"><a href="#policy" aria-controls="profile" role="tab" data-toggle="tab"> Return & Policy</a></li>
                        <li role="presentation"><a href="#reviews" aria-controls="messages" role="tab" data-toggle="tab">Reviews(<?php echo e(\App\Review::where('productid',$productdata->id)->count()); ?>)</a></li>
                    </ul>

                    <!-- Tab panes -->
                    <div class="tab-content">
                        <div role="tabpanel" class="tab-pane active" id="description">
                            <?php echo $productdata->description; ?>

                        </div>
                        <div role="tabpanel" class="tab-pane" id="policy">
                            <?php echo $productdata->policy; ?>

                        </div>
                        <div role="tabpanel" class="tab-pane" id="reviews">
                            <h3>Write a Review</h3>
                            <hr>
                            <div class="row" style="margin-bottom: 20px">
                                <div class="col-md-6">
                                    <div class='starrr' id='star1'></div>
                                    <div>
                                        <span class='your-choice-was' style='display: none;'>
                                            Your rating is: <span class='choice'></span>.
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <form method="POST" action="<?php echo e(route('review.submit')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <input type="hidden" name="rating" id="rate" value="5">
                                <input type="hidden" name="productid" value="<?php echo e($productdata->id); ?>">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input name="name" placeholder="Full Name" class="form-control" type="text" required>

                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <input name="email" placeholder="Your Email" class="form-control" type="email" required>

                                        </div>
                                    </div>
                                </div>
                                <!-- Text input-->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <textarea name="review" rows="6" placeholder="Review Description" class="form-control"></textarea>
                                        </div>
                                    </div>
                                </div>

                                <div id="resp" class="col-md-6">
                                    <?php if($errors->has('error')): ?>
                                        <span class="help-block">
                                <strong><?php echo e($errors->first('password')); ?></strong>
                            </span>
                                    <?php endif; ?>
                                </div>
                                <!-- Button -->
                                <div class="row">
                                    <div class="form-group">
                                        <label class="col-md-3 control-label"></label>
                                        <div class="col-md-4 col-md-offset-2">
                                            <button type="submit" class="button style-10" id="LoginButton"><strong>Submit Review</strong></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                            <hr>
                            <h3>Reviews:</h3>
                            <hr>
                            <?php $__empty_1 = true; $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <div class="row rating-row">
                                    <div class="col-md-3">
                                        <strong><?php echo e($review->name); ?></strong>
                                        <div class="rating-box">
                                            <?php for($i=1;$i<=5;$i++): ?>
                                                <?php if($i <= $review->rating): ?>
                                                    <div class="star"><i class="fa fa-star"></i></div>
                                                <?php else: ?>
                                                    <div class="star"><i class="fa fa-star-o"></i></div>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </div>
                                        <div class="rating-date"><?php echo e($review->review_date); ?></div>
                                    </div>
                                    <div class="col-md-8">
                                        <?php echo e($review->review); ?>

                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h4>No review has given yet.</h4>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>

    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script>
    $('#star1').starrr({
        rating: 5,
        change: function(e, value){
            if (value) {
                $('.your-choice-was').show();
                $('.choice').text(value);
                $('#rate').val(value);
            } else {
                $('.your-choice-was').hide();
            }
        }
    });

    $("#showmore").click(function() {
        $('html, body').animate({
            scrollTop: $("#description").offset().top - 200
        }, 1000);
    });

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>